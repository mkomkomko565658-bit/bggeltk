package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.DynamicSuccessBanner
import com.example.ui.components.NavDrawerContent
import com.example.ui.screens.AccountDetailScreen
import com.example.ui.screens.AccountStatementPdfScreen
import com.example.ui.screens.AddAccountScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.AppLockScreen
import com.example.ui.screens.CalculatorModal
import com.example.ui.screens.GoogleDriveBackupScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingStoreSetupScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AccountingViewModel
import com.example.ui.viewmodel.ScreenDestination
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: AccountingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AccountingApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AccountingApp(viewModel: AccountingViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val accounts by viewModel.filteredSummaries.collectAsStateWithLifecycle()
    val selectedCurrency by viewModel.selectedCurrency.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val overallTotals by viewModel.overallTotals.collectAsStateWithLifecycle()
    val activeAccount by viewModel.activeAccount.collectAsStateWithLifecycle()
    val activeTransactions by viewModel.activeTransactions.collectAsStateWithLifecycle()
    val bannerState by viewModel.bannerState.collectAsStateWithLifecycle()
    val isCalculatorOpen by viewModel.isCalculatorOpen.collectAsStateWithLifecycle()
    val isShareDialogOpen by viewModel.isShareDialogOpen.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isDriveSyncing by viewModel.isDriveSyncing.collectAsStateWithLifecycle()
    val driveSyncMessage by viewModel.driveSyncMessage.collectAsStateWithLifecycle()
    val isAppUnlocked by viewModel.isAppUnlocked.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // Back handling
    if (currentScreen !is ScreenDestination.Home && currentScreen !is ScreenDestination.OnboardingStoreSetup) {
        BackHandler {
            viewModel.navigateBack()
        }
    }

    // App Lock screen guard
    if (userProfile.isAppLockEnabled && !isAppUnlocked) {
        AppLockScreen(
            storeName = userProfile.businessName,
            onUnlock = { pin -> viewModel.unlockApp(pin) }
        )
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = currentScreen is ScreenDestination.Home,
        drawerContent = {
            ModalDrawerSheet {
                NavDrawerContent(
                    storeName = userProfile.businessName,
                    userProfile = userProfile,
                    onNavigate = { dest ->
                        viewModel.navigateTo(dest)
                        coroutineScope.launch { drawerState.close() }
                    },
                    onBackupLocal = { viewModel.exportLocalBackup() },
                    onRestoreLocal = { viewModel.showSuccessBanner("جاهز لاستيراد النسخة المحلية") },
                    onSetAppLock = { enabled, pin -> viewModel.setAppLock(enabled, pin) },
                    onLockNow = { viewModel.lockNow() },
                    onCloseDrawer = { coroutineScope.launch { drawerState.close() } }
                )
            }
        }
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxSize()) {
                when (val screen = currentScreen) {
                    is ScreenDestination.OnboardingStoreSetup -> {
                        OnboardingStoreSetupScreen(
                            initialStoreName = userProfile.businessName,
                            initialPhone = userProfile.phone,
                            onCompleteSetup = { storeName, phone, owner, curr ->
                                viewModel.completeStoreSetup(storeName, phone, owner, curr)
                            }
                        )
                    }

                    is ScreenDestination.Home -> {
                        HomeScreen(
                            accounts = accounts,
                            userProfile = userProfile,
                            selectedCurrency = selectedCurrency,
                            selectedCategory = selectedCategory,
                            overallTotals = overallTotals,
                            onSelectCurrency = { viewModel.setSelectedCurrency(it) },
                            onSelectCategory = { viewModel.setSelectedCategory(it) },
                            onOpenDrawer = { coroutineScope.launch { drawerState.open() } },
                            onAddAccountClick = { viewModel.navigateTo(ScreenDestination.AddAccount) },
                            onAccountClick = { accountId ->
                                viewModel.navigateTo(ScreenDestination.AccountDetail(accountId))
                            },
                            onOpenAnalytics = { viewModel.navigateTo(ScreenDestination.Analytics) }
                        )
                    }

                    is ScreenDestination.AddAccount -> {
                        AddAccountScreen(
                            onBack = { viewModel.navigateBack() },
                            onAddAccount = { name, phone, curr, cat ->
                                viewModel.addAccount(name, phone, curr, cat)
                            }
                        )
                    }

                    is ScreenDestination.AccountDetail -> {
                        AccountDetailScreen(
                            account = activeAccount,
                            transactions = activeTransactions,
                            bannerState = bannerState,
                            isCalculatorOpen = isCalculatorOpen,
                            isShareDialogOpen = isShareDialogOpen,
                            onBack = { viewModel.navigateBack() },
                            onOpenPdf = { viewModel.navigateTo(ScreenDestination.PdfStatement(screen.accountId)) },
                            onOpenCalculator = { viewModel.openCalculator() },
                            onCloseCalculator = { viewModel.closeCalculator() },
                            onOpenShareDialog = { viewModel.openShareDialog() },
                            onCloseShareDialog = { viewModel.closeShareDialog() },
                            onAddTransaction = { amount, type, details, dateString, imageUri ->
                                viewModel.addTransaction(screen.accountId, amount, type, details, dateString, imageUri)
                            },
                            onDeleteTransaction = { txId -> viewModel.deleteTransaction(txId) },
                            onDeleteAccount = { accId -> viewModel.deleteAccount(accId) },
                            onUpdateDueDate = { date -> viewModel.updateAccountDueDate(screen.accountId, date) },
                            onUpdateAccount = { name, phone, curr, cat ->
                                viewModel.updateAccount(screen.accountId, name, phone, curr, cat)
                            }
                        )
                    }

                    is ScreenDestination.PdfStatement -> {
                        AccountStatementPdfScreen(
                            account = activeAccount,
                            transactions = activeTransactions,
                            userProfile = userProfile,
                            onBack = { viewModel.navigateBack() }
                        )
                    }

                    is ScreenDestination.Reports -> {
                        ReportsScreen(
                            accounts = accounts,
                            selectedCurrency = selectedCurrency,
                            onBack = { viewModel.navigateBack() },
                            onAccountClick = { accountId ->
                                viewModel.navigateTo(ScreenDestination.AccountDetail(accountId))
                            }
                        )
                    }

                    is ScreenDestination.Analytics -> {
                        AnalyticsScreen(
                            accounts = accounts,
                            userProfile = userProfile,
                            onBack = { viewModel.navigateBack() },
                            onAccountClick = { accountId ->
                                viewModel.navigateTo(ScreenDestination.AccountDetail(accountId))
                            }
                        )
                    }

                    is ScreenDestination.GoogleDrive -> {
                        GoogleDriveBackupScreen(
                            userProfile = userProfile,
                            isSyncing = isDriveSyncing,
                            syncMessage = driveSyncMessage,
                            onBack = { viewModel.navigateBack() },
                            onSyncNow = { viewModel.syncWithGoogleDrive() },
                            onRestoreNow = { viewModel.restoreFromGoogleDrive() },
                            onToggleAutoBackup = { viewModel.toggleGoogleDriveAutoBackup(it) },
                            onSetAccount = { viewModel.setGoogleDriveAccount(it) },
                            onLocalExport = { viewModel.exportLocalBackup() }
                        )
                    }

                    is ScreenDestination.Settings -> {
                        SettingsScreen(
                            userProfile = userProfile,
                            onBack = { viewModel.navigateBack() },
                            onNavigateToDrive = { viewModel.navigateTo(ScreenDestination.GoogleDrive) },
                            onClearAllData = { viewModel.clearAllData() },
                            onSaveProfile = { name, address, phone, curr ->
                                viewModel.updateProfile(name, address, phone, curr)
                            }
                        )
                    }
                }

                // Calculator Dialog
                if (isCalculatorOpen) {
                    CalculatorModal(
                        onDismiss = { viewModel.closeCalculator() },
                        onResult = { result ->
                            viewModel.closeCalculator()
                        }
                    )
                }

                // Success notification banner
                DynamicSuccessBanner(
                    state = bannerState,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
        }
    }
}
