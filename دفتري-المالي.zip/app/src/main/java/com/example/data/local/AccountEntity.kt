package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone: String = "",
    val currency: String = "محلي",
    val category: String = "عام",
    val dueDate: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
