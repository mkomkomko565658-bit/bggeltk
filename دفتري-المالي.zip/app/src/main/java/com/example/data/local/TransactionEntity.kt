package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = AccountEntity::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["accountId"])]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val accountId: Long,
    val amount: Double,
    val type: String,
    val details: String = "",
    val dateString: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val imageUri: String? = null
) {
    companion object {
        const val TYPE_CREDIT = "CREDIT"
        const val TYPE_DEBT = "DEBT"
    }
}
