package com.example.data.model

data class AccountSummary(
    val id: Long,
    val name: String,
    val phone: String,
    val currency: String,
    val category: String,
    val totalCredit: Double,
    val totalDebt: Double,
    val netBalance: Double,
    val lastTransactionDate: String,
    val transactionCount: Int,
    val dueDate: String = ""
)
