package com.example.data.model

data class TransactionWithRunningBalance(
    val id: Long,
    val accountId: Long,
    val amount: Double,
    val type: String,
    val details: String,
    val dateString: String,
    val timestamp: Long,
    val imageUri: String? = null,
    val runningBalance: Double
)
