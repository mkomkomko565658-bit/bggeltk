package com.example.data.model

data class UserProfile(
    val businessName: String = "بقالتك",
    val phone: String = "",
    val ownerName: String = "",
    val defaultCurrency: String = "محلي",
    val isSetupCompleted: Boolean = false,
    val isGoogleDriveConnected: Boolean = false,
    val googleDriveEmail: String = "",
    val autoBackupEnabled: Boolean = true,
    val lastBackupDate: String = "لم يتم النسخ بعد",
    val isAppLockEnabled: Boolean = false,
    val appLockPin: String = ""
)
