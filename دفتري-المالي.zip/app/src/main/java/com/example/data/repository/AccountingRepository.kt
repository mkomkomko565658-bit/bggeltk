package com.example.data.repository

import android.content.Context
import com.example.data.local.AccountDao
import com.example.data.local.AccountEntity
import com.example.data.local.TransactionDao
import com.example.data.local.TransactionEntity
import com.example.data.model.AccountSummary
import com.example.data.model.TransactionWithRunningBalance
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import org.json.JSONArray
import org.json.JSONObject

class AccountingRepository(
    private val accountDao: AccountDao,
    private val transactionDao: TransactionDao,
    private val context: Context
) {
    val allAccounts: Flow<List<AccountEntity>> = accountDao.getAllAccounts()
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()

    fun getAccountById(id: Long): Flow<AccountEntity?> = accountDao.getAccountById(id)

    suspend fun getAccountByIdDirect(id: Long): AccountEntity? = accountDao.getAccountByIdDirect(id)

    fun getAccountSummaries(): Flow<List<AccountSummary>> {
        return combine(allAccounts, allTransactions) { accounts, transactions ->
            accounts.map { account ->
                val txs = transactions.filter { it.accountId == account.id }
                var credit = 0.0
                var debt = 0.0
                var lastDate = ""
                txs.forEach { tx ->
                    if (tx.type == TransactionEntity.TYPE_CREDIT) {
                        credit += tx.amount
                    } else {
                        debt += tx.amount
                    }
                    if (tx.dateString.isNotBlank()) {
                        lastDate = tx.dateString
                    }
                }
                AccountSummary(
                    id = account.id,
                    name = account.name,
                    phone = account.phone,
                    currency = account.currency,
                    category = account.category,
                    totalCredit = credit,
                    totalDebt = debt,
                    netBalance = credit - debt,
                    lastTransactionDate = lastDate,
                    transactionCount = txs.size,
                    dueDate = account.dueDate
                )
            }
        }
    }

    fun getTransactionsWithBalance(accountId: Long): Flow<List<TransactionWithRunningBalance>> {
        return transactionDao.getTransactionsForAccount(accountId).combine(
            accountDao.getAccountById(accountId)
        ) { txs, _ ->
            var currentBalance = 0.0
            txs.map { tx ->
                if (tx.type == TransactionEntity.TYPE_CREDIT) {
                    currentBalance += tx.amount
                } else {
                    currentBalance -= tx.amount
                }
                TransactionWithRunningBalance(
                    id = tx.id,
                    accountId = tx.accountId,
                    amount = tx.amount,
                    type = tx.type,
                    details = tx.details,
                    dateString = tx.dateString,
                    timestamp = tx.timestamp,
                    imageUri = tx.imageUri,
                    runningBalance = currentBalance
                )
            }
        }
    }

    suspend fun insertAccount(account: AccountEntity): Long {
        return accountDao.insertAccount(account)
    }

    suspend fun updateAccount(account: AccountEntity) {
        accountDao.updateAccount(account)
    }

    suspend fun updateAccountDueDate(accountId: Long, dueDate: String) {
        val account = accountDao.getAccountByIdDirect(accountId)
        if (account != null) {
            accountDao.updateAccount(account.copy(dueDate = dueDate))
        }
    }

    suspend fun deleteAccount(account: AccountEntity) {
        accountDao.deleteAccount(account)
    }

    suspend fun deleteAccountById(id: Long) {
        accountDao.deleteAccountById(id)
    }

    suspend fun insertTransaction(transaction: TransactionEntity): Long {
        return transactionDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(id: Long) {
        transactionDao.deleteTransactionById(id)
    }

    suspend fun clearAll() {
        transactionDao.clearAll()
        accountDao.clearAll()
    }

    suspend fun exportDatabaseToJson(): String {
        val json = JSONObject()
        val accountsDirect = accountDao.getAllAccounts()
        val txsDirect = transactionDao.getAllTransactionsDirect()

        val accArray = JSONArray()
        // Query direct accounts
        val currentAccounts = mutableListOf<AccountEntity>()
        // To read directly, collect single or query
        val accs = accountDao.getAccountByIdDirect(0) // or fallback
        // We can query all accounts direct
        json.put("exportedAt", System.currentTimeMillis())
        json.put("app", "بقالتك")
        return json.toString()
    }
}
