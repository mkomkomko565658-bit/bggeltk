package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForwardIos
import androidx.compose.material.icons.outlined.AddToDrive
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.UserProfile
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.InkBlack
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun NavDrawerContent(
    storeName: String,
    userProfile: UserProfile = UserProfile(),
    onNavigate: (ScreenDestination) -> Unit,
    onBackupLocal: () -> Unit,
    onRestoreLocal: () -> Unit,
    onSetAppLock: (Boolean, String) -> Unit = { _, _ -> },
    onLockNow: () -> Unit = {},
    onCloseDrawer: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var showPinDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(Color.White)
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
    ) {
        // Header Graphic
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp, bottom = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(92.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color.White)
                    .border(2.dp, GreenPrimary, RoundedCornerShape(26.dp))
                    .shadow(6.dp, RoundedCornerShape(26.dp), spotColor = GreenPrimary.copy(alpha = 0.4f)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.baqalatok_icon_1790844086417),
                    contentDescription = "شعار بقالتك",
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Text(
            text = "بقالتك",
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = InkBlack,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(
            text = if (storeName.isNotBlank() && storeName != "بقالتك") storeName else "إدارة حسابات وديون البقالة",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF71717A),
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 14.dp)
        )

        HorizontalDivider(
            color = Color(0xFFE4E4E7),
            thickness = 1.dp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        // Menu items
        DrawerMenuItem(
            icon = Icons.Outlined.PersonAdd,
            title = "إضافة مدين / حساب",
            onClick = {
                onCloseDrawer()
                onNavigate(ScreenDestination.AddAccount)
            }
        )

        DrawerMenuItem(
            icon = Icons.Outlined.Assessment,
            title = "التقارير المالية",
            hasTrailingArrow = true,
            onClick = {
                onCloseDrawer()
                onNavigate(ScreenDestination.Reports)
            }
        )

        DrawerMenuItem(
            icon = Icons.Outlined.QueryStats,
            title = "لوحة الإحصائيات والأرباح",
            hasTrailingArrow = true,
            onClick = {
                onCloseDrawer()
                onNavigate(ScreenDestination.Analytics)
            }
        )

        DrawerMenuItem(
            icon = Icons.Outlined.CloudUpload,
            title = "حفظ نسخة احتياطية",
            onClick = {
                onCloseDrawer()
                onBackupLocal()
            }
        )

        DrawerMenuItem(
            icon = Icons.Outlined.CloudDownload,
            title = "استرجاع نسخة احتياطية",
            onClick = {
                onCloseDrawer()
                onRestoreLocal()
            }
        )

        DrawerMenuItem(
            icon = Icons.Outlined.AddToDrive,
            title = "جوجل درايف (Google Drive)",
            onClick = {
                onCloseDrawer()
                onNavigate(ScreenDestination.GoogleDrive)
            }
        )

        DrawerMenuItem(
            icon = if (userProfile.isAppLockEnabled) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
            title = if (userProfile.isAppLockEnabled) "قفل الأمان برمز PIN (مفعّل ✓)" else "تفعيل قفل الأمان برمز PIN",
            onClick = {
                pinInput = userProfile.appLockPin
                showPinDialog = true
            }
        )

        if (userProfile.isAppLockEnabled) {
            DrawerMenuItem(
                icon = Icons.Outlined.Lock,
                title = "قفل التطبيق الآن 🔒",
                onClick = {
                    onCloseDrawer()
                    onLockNow()
                }
            )
        }

        DrawerMenuItem(
            icon = Icons.Outlined.Settings,
            title = "إعدادات البقالة",
            onClick = {
                onCloseDrawer()
                onNavigate(ScreenDestination.Settings)
            }
        )

        DrawerMenuItem(
            icon = Icons.Outlined.Share,
            title = "مشاركة التطبيق",
            onClick = {
                onCloseDrawer()
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "أنصحك بتحميل تطبيق \"بقالتك\" لمتابعة ديون العملاء وحسابات المتجر بسهولة واحترافية بدون إنترنت!"
                    )
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "مشاركة تطبيق بقالتك"))
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Ad Banner inside Drawer footer
        Box(modifier = Modifier.padding(horizontal = 14.dp)) {
            AdBannerCard()
        }
    }

    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = {
                Text(
                    text = if (userProfile.isAppLockEnabled) "إدارة قفل الأمان" else "تعيين رمز PIN للأمان",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = InkBlack
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "أدخل رمز PIN من 4 أرقام لحماية سجلات الحسابات والديون عند فتح التطبيق:",
                        fontSize = 13.sp,
                        color = Color(0xFF64748B)
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) pinInput = it },
                        label = { Text("رمز PIN (4 أرقام)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinInput.length == 4) {
                            onSetAppLock(true, pinInput)
                            showPinDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                ) {
                    Text("حفظ وتفعيل", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                if (userProfile.isAppLockEnabled) {
                    TextButton(onClick = {
                        onSetAppLock(false, "")
                        showPinDialog = false
                    }) {
                        Text("إلغاء القفل", color = DebtRed)
                    }
                } else {
                    TextButton(onClick = { showPinDialog = false }) {
                        Text("إلغاء", color = Color.Gray)
                    }
                }
            }
        )
    }
}

@Composable
private fun DrawerMenuItem(
    icon: ImageVector,
    title: String,
    hasTrailingArrow: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = GreenPrimary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = InkBlack,
            modifier = Modifier.weight(1f)
        )
        if (hasTrailingArrow) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowForwardIos,
                contentDescription = null,
                tint = Color(0xFFA1A1AA),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
