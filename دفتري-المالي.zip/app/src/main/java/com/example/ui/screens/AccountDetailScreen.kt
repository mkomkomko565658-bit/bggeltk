package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AccountEntity
import com.example.data.local.TransactionEntity
import com.example.data.model.TransactionWithRunningBalance
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GreenLight
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.InkBlack
import com.example.ui.viewmodel.SuccessBannerState
import com.example.util.ExportUtil
import com.example.util.WhatsAppReminderUtil
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountDetailScreen(
    account: AccountEntity?,
    transactions: List<TransactionWithRunningBalance>,
    bannerState: SuccessBannerState,
    isCalculatorOpen: Boolean,
    isShareDialogOpen: Boolean,
    onBack: () -> Unit,
    onOpenPdf: () -> Unit,
    onOpenCalculator: () -> Unit,
    onCloseCalculator: () -> Unit,
    onOpenShareDialog: () -> Unit,
    onCloseShareDialog: () -> Unit,
    onAddTransaction: (amount: Double, type: String, details: String, dateString: String, imageUri: String?) -> Unit,
    onDeleteTransaction: (Long) -> Unit,
    onDeleteAccount: (Long) -> Unit,
    onUpdateDueDate: (String) -> Unit = {},
    onUpdateAccount: (name: String, phone: String, currency: String, category: String) -> Unit = { _, _, _, _ -> }
) {
    val context = LocalContext.current
    val customerName = account?.name ?: "المدين"
    val currency = account?.currency ?: "محلي"

    // Transaction form state
    var amountInput by remember { mutableStateOf("") }
    var detailsInput by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TransactionEntity.TYPE_DEBT) } // TYPE_DEBT: عليه, TYPE_CREDIT: له
    var dateInput by remember {
        mutableStateOf(SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()))
    }
    var formError by remember { mutableStateOf<String?>(null) }

    // Dialogs & menus
    var showMoreMenu by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showEditAccountDialog by remember { mutableStateOf(false) }
    var txToDelete by remember { mutableStateOf<Long?>(null) }

    // Search inside transactions
    var txSearchQuery by remember { mutableStateOf("") }
    var txFilterType by remember { mutableStateOf("الكل") } // "الكل", "له", "عليه"

    // Calculate totals
    val totalCredit = transactions.filter { it.type == TransactionEntity.TYPE_CREDIT }.sumOf { it.amount }
    val totalDebt = transactions.filter { it.type == TransactionEntity.TYPE_DEBT }.sumOf { it.amount }
    val netBalance = totalCredit - totalDebt

    val filteredTransactions = remember(transactions, txSearchQuery, txFilterType) {
        transactions.filter { tx ->
            val matchesQuery = txSearchQuery.isBlank() || tx.details.contains(txSearchQuery, ignoreCase = true)
            val matchesType = when (txFilterType) {
                "له" -> tx.type == TransactionEntity.TYPE_CREDIT
                "عليه" -> tx.type == TransactionEntity.TYPE_DEBT
                else -> true
            }
            matchesQuery && matchesType
        }.reversed() // Show newest first
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = customerName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkBlack,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${account?.category ?: "عام"} • $currency",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = InkBlack)
                    }
                },
                actions = {
                    IconButton(onClick = onOpenCalculator, modifier = Modifier.testTag("calculator_button")) {
                        Icon(Icons.Default.Calculate, contentDescription = "آلة حاسبة", tint = InkBlack)
                    }
                    IconButton(onClick = onOpenPdf, modifier = Modifier.testTag("pdf_button")) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "كشف حساب PDF", tint = GreenPrimary)
                    }
                    IconButton(onClick = onOpenShareDialog, modifier = Modifier.testTag("share_notice_button")) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة إشعار", tint = GreenPrimary)
                    }
                    Box {
                        IconButton(onClick = { showMoreMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "المزيد", tint = InkBlack)
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("تعديل بيانات الحساب") },
                                onClick = {
                                    showMoreMenu = false
                                    showEditAccountDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = GreenPrimary) }
                            )
                            DropdownMenuItem(
                                text = { Text("تصدير كشف إكسل (CSV)") },
                                onClick = {
                                    showMoreMenu = false
                                    if (account != null) {
                                        ExportUtil.exportStatementToCsv(context, account, transactions)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("حذف الحساب بالكامل", color = DebtRed) },
                                onClick = {
                                    showMoreMenu = false
                                    showDeleteConfirmDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = DebtRed) }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF9FAFB)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Balance & Contact Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "الرصيد الصافي الحالي",
                                    fontSize = 13.sp,
                                    color = Color.Gray
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "%.2f %s".format(Locale.US, abs(netBalance), currency),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        netBalance > 0 -> GreenPrimary
                                        netBalance < 0 -> DebtRed
                                        else -> Color.DarkGray
                                    }
                                )
                                Text(
                                    text = when {
                                        netBalance > 0 -> "له (مستحق له دفعه)"
                                        netBalance < 0 -> "عليه (دين مستحق للبقالة)"
                                        else -> "الحساب خالص 0.00"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = when {
                                        netBalance > 0 -> GreenPrimary
                                        netBalance < 0 -> DebtRed
                                        else -> Color.DarkGray
                                    }
                                )
                            }

                            // Quick Contact Action
                            if (account?.phone?.isNotBlank() == true) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(
                                        onClick = { ExportUtil.callCustomer(context, account.phone) },
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(GreenLight)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Call,
                                            contentDescription = "اتصال",
                                            tint = GreenPrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            val reminderMsg = WhatsAppReminderUtil.buildReminderMessage(
                                                businessName = "بقالتك",
                                                customerName = account.name,
                                                netBalance = netBalance,
                                                currency = currency,
                                                dueDate = account.dueDate
                                            )
                                            WhatsAppReminderUtil.sendReminder(context, account.phone, reminderMsg)
                                        },
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE8F5E9))
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "واتساب",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Mini summary row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF9FAFB))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("إجمالي ما عليه (دين)", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    "%.2f".format(Locale.US, totalDebt),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DebtRed
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("إجمالي ما له (دفع)", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    "%.2f".format(Locale.US, totalCredit),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GreenPrimary
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("عدد العمليات", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    "${transactions.size}",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = InkBlack
                                )
                            }
                        }
                    }
                }
            }

            // New Transaction Form Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "تسجيل حركة جديدة في الحساب",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkBlack
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Type Toggle (عليه دين vs له دفعة)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF3F4F6))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selectedType == TransactionEntity.TYPE_DEBT) DebtRed else Color.Transparent
                                    )
                                    .clickable { selectedType = TransactionEntity.TYPE_DEBT }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDownward,
                                        contentDescription = null,
                                        tint = if (selectedType == TransactionEntity.TYPE_DEBT) Color.White else DebtRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "عليه (دين جديد)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedType == TransactionEntity.TYPE_DEBT) Color.White else Color.DarkGray
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selectedType == TransactionEntity.TYPE_CREDIT) GreenPrimary else Color.Transparent
                                    )
                                    .clickable { selectedType = TransactionEntity.TYPE_CREDIT }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (selectedType == TransactionEntity.TYPE_CREDIT) Color.White else GreenPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "له (دفعة مسددة)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedType == TransactionEntity.TYPE_CREDIT) Color.White else Color.DarkGray
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Amount input
                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = {
                                amountInput = it
                                formError = null
                            },
                            label = { Text("المبلغ ($currency) *") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Payments, contentDescription = null, tint = GreenPrimary)
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GreenPrimary,
                                focusedLabelColor = GreenPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("transaction_amount_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Details input
                        OutlinedTextField(
                            value = detailsInput,
                            onValueChange = { detailsInput = it },
                            label = { Text("البيان / تفاصيل الحركة (اختياري)") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GreenPrimary,
                                focusedLabelColor = GreenPrimary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("transaction_details_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Date input
                        OutlinedTextField(
                            value = dateInput,
                            onValueChange = { dateInput = it },
                            label = { Text("التاريخ (سنة/شهر/يوم)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.CalendarToday, contentDescription = null, tint = GreenPrimary)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GreenPrimary,
                                focusedLabelColor = GreenPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        AnimatedVisibility(visible = formError != null) {
                            Text(
                                text = formError ?: "",
                                color = DebtRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val amount = amountInput.toDoubleOrNull()
                                if (amount == null || amount <= 0.0) {
                                    formError = "يرجى إدخال مبلغ صحيح أكبر من صفر"
                                } else {
                                    val safeDetails = detailsInput.ifBlank {
                                        if (selectedType == TransactionEntity.TYPE_DEBT) "دين مشتريات" else "دفعة نقدية"
                                    }
                                    onAddTransaction(amount, selectedType, safeDetails, dateInput, null)
                                    amountInput = ""
                                    detailsInput = ""
                                    formError = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedType == TransactionEntity.TYPE_DEBT) DebtRed else GreenPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("add_transaction_submit_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedType == TransactionEntity.TYPE_DEBT) "تسجيل الدين" else "تسجيل الدفعة",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Transactions Filter & Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "كشف العمليات (${filteredTransactions.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("الكل", "له", "عليه").forEach { filter ->
                            val isSelected = txFilterType == filter
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) GreenPrimary else Color(0xFFE5E7EB))
                                    .clickable { txFilterType = filter }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = filter,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else InkBlack
                                )
                            }
                        }
                    }
                }
            }

            if (filteredTransactions.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد حركات مسجلة تطابق التصفية",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                }
            } else {
                items(filteredTransactions, key = { it.id }) { tx ->
                    TransactionItemCard(
                        tx = tx,
                        currency = currency,
                        onDelete = { txToDelete = tx.id }
                    )
                }
            }
        }
    }

    // Delete Transaction Dialog
    if (txToDelete != null) {
        AlertDialog(
            onDismissRequest = { txToDelete = null },
            title = { Text("حذف المعاملة", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف هذه المعاملة؟ سيتم تعديل الرصيد تلقائياً.") },
            confirmButton = {
                Button(
                    onClick = {
                        txToDelete?.let { onDeleteTransaction(it) }
                        txToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DebtRed)
                ) {
                    Text("حذف", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { txToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Delete Entire Account Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("حذف الحساب بالكامل", fontWeight = FontWeight.Bold, color = DebtRed) },
            text = { Text("هل أنت متأكد من رغبتك في حذف حساب \"$customerName\" وجميع عملياته المسجلة؟ هذا الإجراء لا يمكن التراجع عنه.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        account?.id?.let { onDeleteAccount(it) }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DebtRed)
                ) {
                    Text("نعم، حذف الحساب", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Edit Account Dialog
    if (showEditAccountDialog && account != null) {
        var editName by remember { mutableStateOf(account.name) }
        var editPhone by remember { mutableStateOf(account.phone) }
        var editCategory by remember { mutableStateOf(account.category) }
        var editCurrency by remember { mutableStateOf(account.currency) }

        AlertDialog(
            onDismissRequest = { showEditAccountDialog = false },
            title = { Text("تعديل بيانات الحساب", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("اسم العميل / المورد *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("رقم الهاتف") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editName.isNotBlank()) {
                            onUpdateAccount(editName, editPhone, editCurrency, editCategory)
                            showEditAccountDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                ) {
                    Text("حفظ التعديلات", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditAccountDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Share notice dialog
    ShareNoticeDialog(
        isOpen = isShareDialogOpen,
        customerName = customerName,
        phoneNumber = account?.phone ?: "",
        currency = currency,
        balance = netBalance,
        lastTransactionDetail = transactions.lastOrNull()?.details ?: "",
        onDismiss = onCloseShareDialog
    )
}

@Composable
fun TransactionItemCard(
    tx: TransactionWithRunningBalance,
    currency: String,
    onDelete: () -> Unit
) {
    val isCredit = tx.type == TransactionEntity.TYPE_CREDIT

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (isCredit) GreenLight else Color(0xFFFEF2F2)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isCredit) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = if (isCredit) GreenPrimary else DebtRed,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tx.details.ifBlank { if (isCredit) "دفعة مستلمة" else "دين جديد" },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = InkBlack
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tx.dateString,
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الرصيد: %.2f".format(Locale.US, abs(tx.runningBalance)),
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }
            }

            // Amount
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isCredit) "+" else "-"}%.2f".format(Locale.US, tx.amount),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCredit) GreenPrimary else DebtRed
                )
                Text(
                    text = currency,
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف الحركة",
                    tint = Color.LightGray,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
