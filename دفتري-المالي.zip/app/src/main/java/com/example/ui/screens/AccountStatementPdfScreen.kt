package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AccountEntity
import com.example.data.local.TransactionEntity
import com.example.data.model.TransactionWithRunningBalance
import com.example.data.model.UserProfile
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GreenLight
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.InkBlack
import com.example.util.ExportUtil
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountStatementPdfScreen(
    account: AccountEntity?,
    transactions: List<TransactionWithRunningBalance>,
    userProfile: UserProfile,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val customerName = account?.name ?: "العميل"
    val currency = account?.currency ?: "محلي"
    val currentDate = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date())

    val totalCredit = transactions.filter { it.type == TransactionEntity.TYPE_CREDIT }.sumOf { it.amount }
    val totalDebt = transactions.filter { it.type == TransactionEntity.TYPE_DEBT }.sumOf { it.amount }
    val netBalance = totalCredit - totalDebt

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "كشف حساب مفصل",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("pdf_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = InkBlack)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        if (account != null) {
                            ExportUtil.exportStatementToCsv(context, account, transactions)
                        }
                    }) {
                        Icon(Icons.Default.FileDownload, contentDescription = "تصدير CSV", tint = GreenPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF3F4F6)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Printable Statement Sheet
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = userProfile.businessName.ifBlank { "بقالتك" },
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GreenPrimary
                                )
                                if (userProfile.phone.isNotBlank()) {
                                    Text("هاتف: ${userProfile.phone}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("كشف حساب رسمي", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = InkBlack)
                                Text("التاريخ: $currentDate", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Customer Details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("اسم الحساب: $customerName", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = InkBlack)
                                if (account?.phone?.isNotBlank() == true) {
                                    Text("الهاتف: ${account.phone}", fontSize = 12.sp, color = Color.DarkGray)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("التصنيف: ${account?.category ?: "عام"}", fontSize = 12.sp, color = Color.DarkGray)
                                Text("العملة: $currency", fontSize = 12.sp, color = Color.DarkGray)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Totals Summary Box
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF9FAFB))
                                .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("إجمالي الديون", fontSize = 11.sp, color = Color.Gray)
                                Text("%.2f".format(Locale.US, totalDebt), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = DebtRed)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("إجمالي المدفوعات", fontSize = 11.sp, color = Color.Gray)
                                Text("%.2f".format(Locale.US, totalCredit), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenPrimary)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("الرصيد المتبقي", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    "%.2f".format(Locale.US, abs(netBalance)),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (netBalance > 0) GreenPrimary else if (netBalance < 0) DebtRed else Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }

            // Transactions Table Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(GreenPrimary)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("التاريخ والبيان", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                    Text("المبلغ", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Text("الرصيد", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                }
            }

            // Transactions Table Rows
            items(transactions, key = { it.id }) { tx ->
                val isCredit = tx.type == TransactionEntity.TYPE_CREDIT
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(2f)) {
                        Text(tx.details.ifBlank { if (isCredit) "دفعة" else "دين" }, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = InkBlack)
                        Text(tx.dateString, fontSize = 10.sp, color = Color.Gray)
                    }

                    Text(
                        text = "${if (isCredit) "+" else "-"}%.2f".format(Locale.US, tx.amount),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCredit) GreenPrimary else DebtRed,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = "%.2f".format(Locale.US, abs(tx.runningBalance)),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.DarkGray,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Bottom action buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            if (account != null) {
                                ExportUtil.exportStatementToCsv(context, account, transactions)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ الكشف (CSV)")
                    }

                    OutlinedButton(
                        onClick = {
                            val textContent = buildString {
                                appendLine("=== كشف حساب من ${userProfile.businessName} ===")
                                appendLine("العميل: $customerName")
                                appendLine("التاريخ: $currentDate")
                                appendLine("الرصيد المتبقي: %.2f %s".format(Locale.US, abs(netBalance), currency))
                                appendLine("--------------------------------")
                                transactions.forEach {
                                    val sign = if (it.type == TransactionEntity.TYPE_CREDIT) "(دفعة +)" else "(دين -)"
                                    appendLine("${it.dateString}: ${it.details} - ${it.amount} $sign")
                                }
                            }
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, textContent)
                            }
                            context.startActivity(Intent.createChooser(intent, "إرسال كشف الحساب عبر"))
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مشاركة نصية")
                    }
                }
            }
        }
    }
}
