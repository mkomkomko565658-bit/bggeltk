package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.MonetizationOn
import androidx.compose.material.icons.outlined.TrendingDown
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountSummary
import com.example.data.model.UserProfile
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GreenLight
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.InkBlack
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
    accounts: List<AccountSummary>,
    userProfile: UserProfile,
    onBack: () -> Unit,
    onAccountClick: (Long) -> Unit
) {
    val totalDebt = accounts.sumOf { it.totalDebt }
    val totalCredit = accounts.sumOf { it.totalCredit }
    val totalAccounts = accounts.size
    val debtorsCount = accounts.count { it.netBalance < 0 }
    val settledCount = accounts.count { it.netBalance == 0.0 && it.transactionCount > 0 }
    val creditorsCount = accounts.count { it.netBalance > 0 }

    val topDebtors = accounts
        .filter { it.netBalance < 0 }
        .sortedBy { it.netBalance } // Most negative first
        .take(5)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "لوحة الإحصائيات والأرباح",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("analytics_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = InkBlack)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF9FAFB)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Grid of 4 Key Stats
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatMetricCard(
                            title = "إجمالي ديون العملاء",
                            value = "%.2f".format(Locale.US, totalDebt),
                            subtitle = "$debtorsCount عملاء مدينين",
                            icon = Icons.Outlined.TrendingDown,
                            iconColor = DebtRed,
                            backgroundColor = Color(0xFFFEF2F2),
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            title = "إجمالي ما عليك",
                            value = "%.2f".format(Locale.US, totalCredit),
                            subtitle = "$creditorsCount موردين",
                            icon = Icons.Outlined.MonetizationOn,
                            iconColor = GreenPrimary,
                            backgroundColor = GreenLight,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatMetricCard(
                            title = "إجمالي الحسابات",
                            value = "$totalAccounts",
                            subtitle = "عميل ومورد مسجل",
                            icon = Icons.Outlined.Group,
                            iconColor = Color(0xFF1E40AF),
                            backgroundColor = Color(0xFFEFF6FF),
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            title = "الحسابات الخالصة",
                            value = "$settledCount",
                            subtitle = "رصيد 0.00 مسدد",
                            icon = Icons.Outlined.CheckCircle,
                            iconColor = Color(0xFF047857),
                            backgroundColor = Color(0xFFECFDF5),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Ratio Progress Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "توزيع الحسابات والديون",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = InkBlack
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        val totalTracked = if (totalAccounts > 0) totalAccounts.toFloat() else 1f
                        val debtRatio = debtorsCount / totalTracked
                        val creditRatio = creditorsCount / totalTracked

                        Text("نسبة العملاء المدينين: ${(debtRatio * 100).toInt()}%", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { debtRatio },
                            color = DebtRed,
                            trackColor = Color(0xFFF3F4F6),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("نسبة الحسابات الدائنة (الموردين): ${(creditRatio * 100).toInt()}%", fontSize = 12.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { creditRatio },
                            color = GreenPrimary,
                            trackColor = Color(0xFFF3F4F6),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                }
            }

            // Top Debtors Section
            item {
                Text(
                    text = "أعلى 5 مدينين مطلوبين للسداد",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack
                )
            }

            if (topDebtors.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد ديون معلقة على العملاء حالياً ✓",
                        fontSize = 13.sp,
                        color = GreenPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                items(topDebtors, key = { it.id }) { debtor ->
                    GrandAccountCard(
                        account = debtor,
                        onClick = { onAccountClick(debtor.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun StatMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    backgroundColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(backgroundColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, fontSize = 11.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = InkBlack)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 10.sp, color = Color.DarkGray)
        }
    }
}
