package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.CreditGreen
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GoldBright
import com.example.ui.theme.InkBlack

@Composable
fun CalculatorModal(
    onDismiss: () -> Unit,
    onResult: (Double) -> Unit
) {
    var display by remember { mutableStateOf("0") }
    var operand1 by remember { mutableStateOf<Double?>(null) }
    var operator by remember { mutableStateOf<String?>(null) }
    var readyForNextInput by remember { mutableStateOf(false) }

    fun onNumber(num: String) {
        if (readyForNextInput || display == "0") {
            display = num
            readyForNextInput = false
        } else {
            display += num
        }
    }

    fun onOp(op: String) {
        operand1 = display.toDoubleOrNull() ?: 0.0
        operator = op
        readyForNextInput = true
    }

    fun calculate() {
        val op1 = operand1 ?: return
        val op2 = display.toDoubleOrNull() ?: return
        val res = when (operator) {
            "+" -> op1 + op2
            "-" -> op1 - op2
            "×" -> op1 * op2
            "÷" -> if (op2 != 0.0) op1 / op2 else 0.0
            else -> op2
        }
        display = if (res % 1.0 == 0.0) res.toLong().toString() else "%.2f".format(res)
        operand1 = null
        operator = null
        readyForNextInput = true
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Display Area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(InkBlack)
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    Text(
                        text = display,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Keypad
                val buttons = listOf(
                    listOf("C", "÷", "×", "⌫"),
                    listOf("7", "8", "9", "-"),
                    listOf("4", "5", "6", "+"),
                    listOf("1", "2", "3", "="),
                    listOf("0", ".", "تم", "")
                )

                buttons.forEach { row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        row.forEach { btn ->
                            if (btn.isNotBlank()) {
                                val isOp = btn in listOf("+", "-", "×", "÷")
                                val isAction = btn in listOf("C", "⌫", "=", "تم")

                                val bgColor = when {
                                    btn == "تم" -> CreditGreen
                                    btn == "=" -> GoldBright
                                    btn == "C" -> DebtRed
                                    isOp -> Color(0xFFF1F5F9)
                                    isAction -> Color(0xFFE2E8F0)
                                    else -> Color(0xFFF8FAFC)
                                }

                                val textColor = when {
                                    btn in listOf("تم", "=", "C") -> Color.White
                                    isOp -> GoldBright
                                    else -> InkBlack
                                }

                                val weight = if (btn == "0") 2f else 1f

                                Box(
                                    modifier = Modifier
                                        .size(if (btn == "0") 110.dp else 52.dp, 52.dp)
                                        .clip(CircleShape)
                                        .background(bgColor)
                                        .clickable {
                                            when (btn) {
                                                "C" -> {
                                                    display = "0"
                                                    operand1 = null
                                                    operator = null
                                                }
                                                "⌫" -> {
                                                    display = if (display.length > 1) display.dropLast(1) else "0"
                                                }
                                                "+", "-", "×", "÷" -> onOp(btn)
                                                "=" -> calculate()
                                                "تم" -> {
                                                    calculate()
                                                    val finalVal = display.toDoubleOrNull() ?: 0.0
                                                    onResult(finalVal)
                                                    onDismiss()
                                                }
                                                "." -> {
                                                    if (!display.contains(".")) display += "."
                                                }
                                                else -> onNumber(btn)
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = btn,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = textColor
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.size(52.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
