package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountSummary
import com.example.data.model.UserProfile
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GoldRoyal
import com.example.ui.theme.GreenLight
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.InkBlack
import com.example.util.ExportUtil
import com.example.util.WhatsAppReminderUtil
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    accounts: List<AccountSummary>,
    userProfile: UserProfile,
    selectedCurrency: String,
    selectedCategory: String,
    overallTotals: Pair<Double, Double>,
    onSelectCurrency: (String) -> Unit,
    onSelectCategory: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    onAddAccountClick: () -> Unit,
    onAccountClick: (Long) -> Unit,
    onOpenAnalytics: () -> Unit = {}
) {
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var currencyDropdownOpen by remember { mutableStateOf(false) }

    val categories = listOf("عام", "عملاء", "موردين", "الكل")
    val currencies = listOf("محلي", "دولار أمريكي", "ريال سعودي", "درهم إماراتي", "دينار", "يورو", "الكل")

    val displayedAccounts = remember(accounts, searchQuery) {
        if (searchQuery.isBlank()) accounts
        else accounts.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (searchOpen) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث عن اسم أو رقم هاتف...", fontSize = 14.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("home_search_input")
                        )
                    } else {
                        Column {
                            Text(
                                text = userProfile.businessName.ifBlank { "بقالتك" },
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                color = InkBlack
                            )
                            if (userProfile.ownerName.isNotBlank()) {
                                Text(
                                    text = userProfile.ownerName,
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer, modifier = Modifier.testTag("drawer_menu_button")) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة الرئيسية", tint = GreenPrimary)
                    }
                },
                actions = {
                    if (searchOpen) {
                        IconButton(onClick = {
                            searchOpen = false
                            searchQuery = ""
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء البحث", tint = Color.Gray)
                        }
                    } else {
                        IconButton(onClick = { searchOpen = true }, modifier = Modifier.testTag("search_toggle_button")) {
                            Icon(Icons.Default.Search, contentDescription = "بحث", tint = InkBlack)
                        }
                        IconButton(onClick = onOpenAnalytics, modifier = Modifier.testTag("analytics_button")) {
                            Icon(Icons.Outlined.QueryStats, contentDescription = "الإحصائيات", tint = GreenPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddAccountClick,
                containerColor = GreenPrimary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("إضافة حساب / مدين", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("add_account_fab")
            )
        },
        containerColor = Color(0xFFF9FAFB)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            // Totals Banner Card
            item {
                TotalsSummaryCard(
                    totalCredit = overallTotals.first,
                    totalDebt = overallTotals.second,
                    selectedCurrency = selectedCurrency,
                    currencyDropdownOpen = currencyDropdownOpen,
                    currencies = currencies,
                    onToggleCurrencyDropdown = { currencyDropdownOpen = it },
                    onSelectCurrency = {
                        onSelectCurrency(it)
                        currencyDropdownOpen = false
                    }
                )
            }

            // Categories Filter Row
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { cat ->
                        val selected = selectedCategory == cat
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectCategory(cat) },
                            label = { Text(cat, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GreenPrimary,
                                selectedLabelColor = Color.White,
                                containerColor = Color.White,
                                labelColor = InkBlack
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = if (selected) GreenPrimary else Color(0xFFE5E7EB)
                            )
                        )
                    }
                }
            }

            // Accounts List Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "قائمة الحسابات (${displayedAccounts.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack
                    )
                }
            }

            if (displayedAccounts.isEmpty()) {
                item {
                    EmptyAccountsView(onAddClick = onAddAccountClick)
                }
            } else {
                items(displayedAccounts, key = { it.id }) { account ->
                    GrandAccountCard(
                        account = account,
                        onClick = { onAccountClick(account.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun TotalsSummaryCard(
    totalCredit: Double,
    totalDebt: Double,
    selectedCurrency: String,
    currencyDropdownOpen: Boolean,
    currencies: List<String>,
    onToggleCurrencyDropdown: (Boolean) -> Unit,
    onSelectCurrency: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .shadow(6.dp, RoundedCornerShape(20.dp), spotColor = GreenPrimary.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ملخص الحسابات الإجمالي",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack
                )

                // Currency selector pill
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF3F4F6))
                            .clickable { onToggleCurrencyDropdown(true) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedCurrency,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GreenPrimary
                        )
                        Icon(
                            Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = GreenPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = currencyDropdownOpen,
                        onDismissRequest = { onToggleCurrencyDropdown(false) }
                    ) {
                        currencies.forEach { curr ->
                            DropdownMenuItem(
                                text = { Text(curr) },
                                onClick = { onSelectCurrency(curr) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Debt card (ديون على العملاء - لي)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFFEF2F2))
                        .border(1.dp, Color(0xFFFECACA), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "لي (ديون العملاء)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = DebtRed
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "%.2f".format(Locale.US, totalDebt),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = DebtRed
                        )
                    }
                }

                // Credit card (مستحقات للموردين - عليّ)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(GreenLight)
                        .border(1.dp, Color(0xFFA7F3D0), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "عليّ (للموردين)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = GreenPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "%.2f".format(Locale.US, totalCredit),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = GreenPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GrandAccountCard(
    account: AccountSummary,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val isCredit = account.netBalance > 0
    val isDebt = account.netBalance < 0

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable(onClick = onClick)
            .testTag("account_card_${account.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCredit) GreenLight else if (isDebt) Color(0xFFFEF2F2) else Color(0xFFF3F4F6)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = account.name.firstOrNull()?.toString() ?: "ح",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCredit) GreenPrimary else if (isDebt) DebtRed else Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = account.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFF3F4F6))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = account.category,
                            fontSize = 10.sp,
                            color = Color.DarkGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (account.phone.isNotBlank()) {
                        Text(
                            text = account.phone,
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    } else if (account.lastTransactionDate.isNotBlank()) {
                        Text(
                            text = "آخر عملية: ${account.lastTransactionDate}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // Quick Contact Buttons (Phone / WhatsApp)
            if (account.phone.isNotBlank()) {
                IconButton(
                    onClick = { ExportUtil.callCustomer(context, account.phone) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "اتصال",
                        tint = GreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Net balance
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "%.2f".format(Locale.US, kotlin.math.abs(account.netBalance)),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        isCredit -> GreenPrimary
                        isDebt -> DebtRed
                        else -> Color.Gray
                    }
                )
                Text(
                    text = when {
                        isCredit -> "له (مستحق)"
                        isDebt -> "عليه (دين)"
                        else -> "خالص"
                    } + " " + account.currency,
                    fontSize = 11.sp,
                    color = when {
                        isCredit -> GreenPrimary
                        isDebt -> DebtRed
                        else -> Color.Gray
                    }
                )
            }
        }
    }
}

@Composable
fun EmptyAccountsView(onAddClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 60.dp, start = 32.dp, end = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(GreenLight),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Person,
                contentDescription = null,
                tint = GreenPrimary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "لا توجد حسابات مسجلة بعد",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = InkBlack
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "اضغط على زر الإضافة بالأسفل لإضافة أول عميل أو مورد وبدء تسجيل المعاملات والديون",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}
