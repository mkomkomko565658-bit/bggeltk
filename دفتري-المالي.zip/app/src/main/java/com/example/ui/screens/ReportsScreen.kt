package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountSummary
import com.example.ui.theme.DebtRed
import com.example.ui.theme.GreenLight
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.InkBlack
import com.example.util.ExportUtil
import java.util.Locale
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    accounts: List<AccountSummary>,
    selectedCurrency: String,
    onBack: () -> Unit,
    onAccountClick: (Long) -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("الكل") }
    val categories = listOf("الكل", "عملاء", "موردين", "عام")

    val filtered = remember(accounts, selectedCategory) {
        if (selectedCategory == "الكل") accounts
        else accounts.filter { it.category == selectedCategory }
    }

    val totalDebt = filtered.sumOf { it.totalDebt }
    val totalCredit = filtered.sumOf { it.totalCredit }
    val netOverall = totalCredit - totalDebt

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "التقارير المالية والديون",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("reports_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = InkBlack)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        ExportUtil.exportAccountsSummaryToCsv(context, accounts)
                    }) {
                        Icon(Icons.Default.FileDownload, contentDescription = "تصدير الملخص CSV", tint = GreenPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF9FAFB)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Category filter row
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        val isSelected = selectedCategory == cat
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Summary Totals Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text("الملخص المالي الشامل", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkBlack)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("إجمالي الديون على العملاء", fontSize = 12.sp, color = Color.Gray)
                                Text("%.2f".format(Locale.US, totalDebt), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DebtRed)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("إجمالي المدفوعات للموردين", fontSize = 12.sp, color = Color.Gray)
                                Text("%.2f".format(Locale.US, totalCredit), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GreenPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الرصيد الصافي العام:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = InkBlack)
                            Text(
                                "%.2f".format(Locale.US, abs(netOverall)),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (netOverall >= 0) GreenPrimary else DebtRed
                            )
                        }
                    }
                }
            }

            // Top Debtors header
            item {
                Text(
                    text = "تفاصيل الحسابات (${filtered.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Accounts
            items(filtered, key = { it.id }) { acc ->
                GrandAccountCard(account = acc, onClick = { onAccountClick(acc.id) })
            }
        }
    }
}
