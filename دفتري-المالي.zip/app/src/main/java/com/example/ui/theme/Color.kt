package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Elegant Emerald, Obsidian, and Gold Color Palette
val GreenPrimary = Color(0xFF059669)
val GreenDark = Color(0xFF064E3B)
val GreenLight = Color(0xFFD1FAE5)
val GreenBorder = Color(0xFFA7F3D0)
val GreenBright = Color(0xFF10B981)

val GoldRoyal = Color(0xFFD97706)
val GoldDark = Color(0xFF92400E)
val GoldBright = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFEF3C7)
val GoldBorder = Color(0xFFFDE68A)

val InkBlack = Color(0xFF0F172A)

val CreditGreen = Color(0xFF059669)
val CreditGreenLight = Color(0xFFD1FAE5)

val DebtRed = Color(0xFFDC2626)
val DebtRedLight = Color(0xFFFEE2E2)
