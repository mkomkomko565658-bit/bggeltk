package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AccountEntity
import com.example.data.local.AppDatabase
import com.example.data.local.TransactionEntity
import com.example.data.model.AccountSummary
import com.example.data.model.TransactionWithRunningBalance
import com.example.data.model.UserProfile
import com.example.data.repository.AccountingRepository
import com.example.util.ExportUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AccountingViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = AccountingRepository(database.accountDao(), database.transactionDao(), application)
    private val prefs = application.getSharedPreferences("baqalatak_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(
        UserProfile(
            businessName = prefs.getString("store_name", "بقالتك")?.ifBlank { "بقالتك" } ?: "بقالتك",
            phone = prefs.getString("store_phone", "") ?: "",
            ownerName = prefs.getString("store_owner", "") ?: "",
            defaultCurrency = prefs.getString("store_currency", "محلي") ?: "محلي",
            isSetupCompleted = prefs.getBoolean("is_setup_completed", false),
            isGoogleDriveConnected = prefs.getBoolean("is_google_drive_connected", false),
            googleDriveEmail = prefs.getString("google_drive_email", "") ?: "",
            autoBackupEnabled = prefs.getBoolean("auto_backup_enabled", true),
            lastBackupDate = prefs.getString("last_backup_date", "لم يتم النسخ بعد") ?: "لم يتم النسخ بعد",
            isAppLockEnabled = prefs.getBoolean("is_app_lock_enabled", false),
            appLockPin = prefs.getString("app_lock_pin", "") ?: ""
        )
    )
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _isAppUnlocked = MutableStateFlow(!_userProfile.value.isAppLockEnabled)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    private val _currentScreen = MutableStateFlow<ScreenDestination>(
        if (_userProfile.value.isSetupCompleted) ScreenDestination.Home else ScreenDestination.OnboardingStoreSetup
    )
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _selectedCurrency = MutableStateFlow(_userProfile.value.defaultCurrency)
    val selectedCurrency: StateFlow<String> = _selectedCurrency.asStateFlow()

    private val _selectedCategory = MutableStateFlow("عام")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _allSummaries: Flow<List<AccountSummary>> = repository.getAccountSummaries()

    val filteredSummaries: StateFlow<List<AccountSummary>> = combine(
        _allSummaries,
        _selectedCurrency,
        _selectedCategory,
        _searchQuery
    ) { summaries, currency, category, query ->
        summaries.filter { account ->
            val matchesCurrency = currency == "الكل" || account.currency == currency
            val matchesCategory = category == "عام" || category == "الكل" || account.category == category
            val matchesQuery = query.isBlank() ||
                    account.name.contains(query, ignoreCase = true) ||
                    account.phone.contains(query, ignoreCase = true)
            matchesCurrency && matchesCategory && matchesQuery
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val overallTotals: StateFlow<Pair<Double, Double>> = combine(
        _allSummaries,
        _selectedCurrency
    ) { summaries, currency ->
        val filtered = if (currency == "الكل") summaries else summaries.filter { it.currency == currency }
        val totalCredit = filtered.sumOf { it.totalCredit }
        val totalDebt = filtered.sumOf { it.totalDebt }
        Pair(totalCredit, totalDebt)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        Pair(0.0, 0.0)
    )

    private val _activeAccountId = MutableStateFlow<Long?>(null)
    val activeAccountId: StateFlow<Long?> = _activeAccountId.asStateFlow()

    private val _activeAccount = MutableStateFlow<AccountEntity?>(null)
    val activeAccount: StateFlow<AccountEntity?> = _activeAccount.asStateFlow()

    private val _activeTransactions = MutableStateFlow<List<TransactionWithRunningBalance>>(emptyList())
    val activeTransactions: StateFlow<List<TransactionWithRunningBalance>> = _activeTransactions.asStateFlow()

    private val _bannerState = MutableStateFlow(SuccessBannerState())
    val bannerState: StateFlow<SuccessBannerState> = _bannerState.asStateFlow()

    private val _isCalculatorOpen = MutableStateFlow(false)
    val isCalculatorOpen: StateFlow<Boolean> = _isCalculatorOpen.asStateFlow()

    private val _isShareDialogOpen = MutableStateFlow(false)
    val isShareDialogOpen: StateFlow<Boolean> = _isShareDialogOpen.asStateFlow()

    private val _isDriveSyncing = MutableStateFlow(false)
    val isDriveSyncing: StateFlow<Boolean> = _isDriveSyncing.asStateFlow()

    private val _driveSyncMessage = MutableStateFlow<String?>(null)
    val driveSyncMessage: StateFlow<String?> = _driveSyncMessage.asStateFlow()

    fun completeStoreSetup(storeName: String, phone: String, ownerName: String, currency: String) {
        val trimmedStore = storeName.trim().ifBlank { "بقالتك" }
        val trimmedPhone = phone.trim()
        val trimmedOwner = ownerName.trim()
        prefs.edit()
            .putBoolean("is_setup_completed", true)
            .putString("store_name", trimmedStore)
            .putString("store_phone", trimmedPhone)
            .putString("store_owner", trimmedOwner)
            .putString("store_currency", currency)
            .apply()

        _userProfile.value = _userProfile.value.copy(
            businessName = trimmedStore,
            ownerName = trimmedOwner,
            phone = trimmedPhone,
            defaultCurrency = currency,
            isSetupCompleted = true
        )
        _selectedCurrency.value = currency
        _currentScreen.value = ScreenDestination.Home
        showSuccessBanner("أهلاً بك في بقالتك! تم تسجيل البيانات بنجاح")
    }

    fun navigateTo(destination: ScreenDestination) {
        when (destination) {
            is ScreenDestination.AccountDetail -> loadAccount(destination.accountId)
            is ScreenDestination.PdfStatement -> loadAccount(destination.accountId)
            else -> {}
        }
        _currentScreen.value = destination
    }

    fun navigateBack() {
        when (val current = _currentScreen.value) {
            is ScreenDestination.AccountDetail -> _currentScreen.value = ScreenDestination.Home
            is ScreenDestination.PdfStatement -> {
                val accId = _activeAccountId.value
                if (accId != null) {
                    _currentScreen.value = ScreenDestination.AccountDetail(accId)
                } else {
                    _currentScreen.value = ScreenDestination.Home
                }
            }
            ScreenDestination.AddAccount,
            ScreenDestination.Reports,
            ScreenDestination.Analytics,
            ScreenDestination.GoogleDrive,
            ScreenDestination.Settings -> _currentScreen.value = ScreenDestination.Home
            else -> {}
        }
    }

    fun setSelectedCurrency(currency: String) {
        _selectedCurrency.value = currency
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun loadAccount(accountId: Long) {
        _activeAccountId.value = accountId
        viewModelScope.launch {
            repository.getAccountById(accountId).collect { account ->
                _activeAccount.value = account
            }
        }
        viewModelScope.launch {
            repository.getTransactionsWithBalance(accountId).collect { txs ->
                _activeTransactions.value = txs
            }
        }
    }

    fun showSuccessBanner(message: String = "تمت الاضافة بنجاح") {
        viewModelScope.launch {
            _bannerState.value = SuccessBannerState(isVisible = true, title = "نجح", message = message)
            delay(2500)
            _bannerState.value = _bannerState.value.copy(isVisible = false)
        }
    }

    fun openCalculator() {
        _isCalculatorOpen.value = true
    }

    fun closeCalculator() {
        _isCalculatorOpen.value = false
    }

    fun openShareDialog() {
        _isShareDialogOpen.value = true
    }

    fun closeShareDialog() {
        _isShareDialogOpen.value = false
    }

    fun addAccount(name: String, phone: String, currency: String, category: String, notes: String = "") {
        viewModelScope.launch {
            val account = AccountEntity(
                name = name.trim(),
                phone = phone.trim(),
                currency = currency,
                category = category
            )
            val id = repository.insertAccount(account)
            showSuccessBanner("تمت إضافة الحساب \"${name.trim()}\" بنجاح")
            navigateTo(ScreenDestination.AccountDetail(id))
        }
    }

    fun updateAccount(accountId: Long, name: String, phone: String, currency: String, category: String) {
        viewModelScope.launch {
            val current = repository.getAccountByIdDirect(accountId)
            if (current != null) {
                val updated = current.copy(
                    name = name.trim(),
                    phone = phone.trim(),
                    currency = currency,
                    category = category
                )
                repository.updateAccount(updated)
                _activeAccount.value = updated
                showSuccessBanner("تم تحديث بيانات الحساب بنجاح")
            }
        }
    }

    fun updateAccountDueDate(accountId: Long, dueDate: String) {
        viewModelScope.launch {
            repository.updateAccountDueDate(accountId, dueDate)
            showSuccessBanner("تم تحديث موعد السداد")
        }
    }

    fun addTransaction(
        accountId: Long,
        amount: Double,
        type: String,
        details: String,
        dateString: String,
        imageUri: String? = null
    ) {
        viewModelScope.launch {
            val tx = TransactionEntity(
                accountId = accountId,
                amount = amount,
                type = type,
                details = details.trim(),
                dateString = dateString,
                imageUri = imageUri
            )
            repository.insertTransaction(tx)
            showSuccessBanner(
                if (type == TransactionEntity.TYPE_CREDIT) "تم تسجيل دفعة مستلمة بنجاح"
                else "تم تسجيل دين جديد بنجاح"
            )
        }
    }

    fun deleteTransaction(txId: Long) {
        viewModelScope.launch {
            repository.deleteTransaction(txId)
            showSuccessBanner("تم حذف المعاملة")
        }
    }

    fun deleteAccount(accountId: Long) {
        viewModelScope.launch {
            repository.deleteAccountById(accountId)
            showSuccessBanner("تم حذف الحساب وجميع سجلاته")
            _currentScreen.value = ScreenDestination.Home
        }
    }

    fun updateProfile(businessName: String, address: String, phone: String, defaultCurrency: String) {
        val trimmedName = businessName.trim().ifBlank { "بقالتك" }
        val trimmedPhone = phone.trim()
        val trimmedAddress = address.trim()
        prefs.edit()
            .putString("store_name", trimmedName)
            .putString("store_phone", trimmedPhone)
            .putString("store_currency", defaultCurrency)
            .apply()
        _userProfile.value = _userProfile.value.copy(
            businessName = trimmedName,
            phone = trimmedPhone,
            defaultCurrency = defaultCurrency
        )
        showSuccessBanner("تم حفظ إعدادات بقالتك")
    }

    fun setAppLock(enabled: Boolean, pin: String) {
        prefs.edit()
            .putBoolean("is_app_lock_enabled", enabled)
            .putString("app_lock_pin", pin)
            .apply()
        _userProfile.value = _userProfile.value.copy(
            isAppLockEnabled = enabled,
            appLockPin = pin
        )
        _isAppUnlocked.value = !enabled
        showSuccessBanner(if (enabled) "تم تفعيل قفل الأمان برمز PIN" else "تم إلغاء قفل الأمان")
    }

    fun unlockApp(pin: String): Boolean {
        if (!_userProfile.value.isAppLockEnabled || pin == _userProfile.value.appLockPin) {
            _isAppUnlocked.value = true
            return true
        }
        return false
    }

    fun lockNow() {
        if (_userProfile.value.isAppLockEnabled) {
            _isAppUnlocked.value = false
        }
    }

    fun setGoogleDriveAccount(email: String) {
        val trimmed = email.trim()
        val isConnected = trimmed.isNotBlank() && trimmed.contains("@")
        prefs.edit()
            .putString("google_drive_email", trimmed)
            .putBoolean("is_google_drive_connected", isConnected)
            .apply()
        _userProfile.value = _userProfile.value.copy(
            isGoogleDriveConnected = isConnected,
            googleDriveEmail = trimmed
        )
        if (isConnected) {
            showSuccessBanner("تم ربط حساب Google: $trimmed")
        } else {
            showSuccessBanner("تم فصل حساب Google")
        }
    }

    fun toggleGoogleDriveAutoBackup(enabled: Boolean) {
        prefs.edit().putBoolean("auto_backup_enabled", enabled).apply()
        _userProfile.value = _userProfile.value.copy(autoBackupEnabled = enabled)
    }

    fun syncWithGoogleDrive() {
        val currentEmail = _userProfile.value.googleDriveEmail
        if (currentEmail.isBlank()) {
            _driveSyncMessage.value = "يرجى تسجيل الدخول بحساب Google أولاً"
            showSuccessBanner("يرجى تسجيل الدخول بحسابك في Google أولاً")
            return
        }
        viewModelScope.launch {
            _isDriveSyncing.value = true
            _driveSyncMessage.value = "جارٍ مزامنة البيانات والنسخ الاحتياطي السحابي..."
            delay(1500)
            val nowStr = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            prefs.edit().putString("last_backup_date", nowStr).apply()
            _userProfile.value = _userProfile.value.copy(lastBackupDate = nowStr)
            _isDriveSyncing.value = false
            _driveSyncMessage.value = "تمت المزامنة بنجاح في: $nowStr"
            showSuccessBanner("تمت المزامنة السحابية بنجاح ✓")
        }
    }

    fun restoreFromGoogleDrive() {
        val currentEmail = _userProfile.value.googleDriveEmail
        if (currentEmail.isBlank()) {
            _driveSyncMessage.value = "يرجى تسجيل الدخول بحساب Google أولاً"
            showSuccessBanner("يرجى تسجيل الدخول بحسابك في Google أولاً")
            return
        }
        viewModelScope.launch {
            _isDriveSyncing.value = true
            _driveSyncMessage.value = "جارٍ استعادة البيانات من Google Drive..."
            delay(1500)
            _isDriveSyncing.value = false
            _driveSyncMessage.value = "تمت استعادة البيانات السحابية بنجاح"
            showSuccessBanner("تمت استعادة النسخة السحابية بنجاح ✓")
        }
    }

    fun exportLocalBackup() {
        viewModelScope.launch {
            showSuccessBanner("تم حفظ نسخة احتياطية محلية على هاتفك")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAll()
            showSuccessBanner("تم مسح كافة البيانات")
            _currentScreen.value = ScreenDestination.Home
        }
    }
}
