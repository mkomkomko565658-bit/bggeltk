package com.example.ui.viewmodel

sealed class ScreenDestination {
    object Home : ScreenDestination()
    object AddAccount : ScreenDestination()
    data class AccountDetail(val accountId: Long) : ScreenDestination()
    data class PdfStatement(val accountId: Long) : ScreenDestination()
    object Reports : ScreenDestination()
    object Analytics : ScreenDestination()
    object GoogleDrive : ScreenDestination()
    object Settings : ScreenDestination()
    object OnboardingStoreSetup : ScreenDestination()
}
