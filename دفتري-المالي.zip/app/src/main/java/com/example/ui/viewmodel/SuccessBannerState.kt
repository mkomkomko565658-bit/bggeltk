package com.example.ui.viewmodel

data class SuccessBannerState(
    val isVisible: Boolean = false,
    val title: String = "نجح",
    val message: String = "تمت الاضافة بنجاح"
)
