package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.local.TransactionEntity
import com.example.data.model.AccountSummary
import com.example.data.model.TransactionWithRunningBalance
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportUtil {

    /**
     * Dials a customer phone number directly.
     */
    fun callCustomer(context: Context, rawPhone: String) {
        if (rawPhone.isBlank()) return
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${rawPhone.trim()}"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun exportStatementToCsv(
        context: Context,
        account: com.example.data.local.AccountEntity,
        transactions: List<TransactionWithRunningBalance>
    ): File? {
        val file = exportStatementToCsv(context, account.name, account.currency, transactions)
        if (file != null) shareFile(context, file, "كشف حساب ${account.name}")
        return file
    }

    /**
     * Exports a customer account statement to a UTF-8 BOM CSV file (Excel-ready).
     */
    fun exportStatementToCsv(
        context: Context,
        accountName: String,
        currency: String,
        transactions: List<TransactionWithRunningBalance>
    ): File? {
        return try {
            val cleanName = accountName.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF]"), "_")
            val fileName = "كشف_حساب_${cleanName}_${System.currentTimeMillis()}.csv"
            val file = File(context.cacheDir, fileName)

            FileOutputStream(file).use { fos ->
                // Write UTF-8 BOM so Excel opens Arabic correctly without encoding issues
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                OutputStreamWriter(fos, StandardCharsets.UTF_8).use { writer ->
                    writer.write("كشف حساب: $accountName\n")
                    writer.write("العملة: $currency\n")
                    val dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                    writer.write("تاريخ التصدير: $dateFormatted\n\n")

                    // Headers
                    writer.write("م,التاريخ,نوع العملية,المبلغ,الرصيد التراكمي,البيان / التفاصيل\n")

                    // Rows
                    transactions.forEachIndexed { index, tx ->
                        val typeName = if (tx.type == TransactionEntity.TYPE_CREDIT) "له (سداد/دفعة)" else "عليه (مشتريات/دين)"
                        val detailsClean = tx.details.replace(",", " - ").replace("\n", " ")
                        writer.write("${index + 1},${tx.dateString},$typeName,${tx.amount},${tx.runningBalance},\"$detailsClean\"\n")
                    }
                }
            }
            file
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Exports all accounts to a CSV summary file.
     */
    fun exportAccountsSummaryToCsv(
        context: Context,
        storeName: String,
        accounts: List<AccountSummary>
    ): File? {
        return try {
            val fileName = "تقرير_حسابات_${storeName}_${System.currentTimeMillis()}.csv"
            val file = File(context.cacheDir, fileName)

            FileOutputStream(file).use { fos ->
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                OutputStreamWriter(fos, StandardCharsets.UTF_8).use { writer ->
                    writer.write("تقرير ديون وحسابات: $storeName\n")
                    val dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                    writer.write("تاريخ التصدير: $dateFormatted\n\n")

                    // Headers
                    writer.write("م,الاسم,رقم الهاتف,التصنيف,العملة,إجمالي لك,إجمالي عليك,الرصيد الصافي,تاريخ آخر حركة\n")

                    accounts.forEachIndexed { index, acc ->
                        val netStatus = if (acc.netBalance < 0) "عليه ${-acc.netBalance}" else if (acc.netBalance > 0) "له ${acc.netBalance}" else "متزن 0"
                        writer.write("${index + 1},\"${acc.name}\",${acc.phone},${acc.category},${acc.currency},${acc.totalCredit},${acc.totalDebt},\"$netStatus\",${acc.lastTransactionDate}\n")
                    }
                }
            }
            file
        } catch (_: Exception) {
            null
        }
    }

    fun exportAccountsSummaryToCsv(
        context: Context,
        accounts: List<AccountSummary>,
        storeName: String = "بقالتك"
    ): File? {
        val file = exportAccountsSummaryToCsv(context, storeName, accounts)
        if (file != null) shareFile(context, file, "تقرير الحسابات")
        return file
    }

    /**
     * Shares any file via Android system share intent using FileProvider.
     */
    fun shareFile(context: Context, file: File, title: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, title).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) {
            android.widget.Toast.makeText(context, "تعذر مشاركة الملف", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
