package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream

object ImageUtil {

    /**
     * Converts a Uri (content:// or file://) to a Base64 data URI string for embedding into HTML / PDF.
     */
    fun getBase64FromUri(context: Context, uriString: String?): String? {
        if (uriString.isNullOrBlank()) return null
        return try {
            val uri = Uri.parse(uriString)
            val inputStream: InputStream? = if (uriString.startsWith("content://") || uriString.startsWith("android.resource://")) {
                context.contentResolver.openInputStream(uri)
            } else if (uriString.startsWith("file://")) {
                File(uri.path ?: "").inputStream()
            } else {
                File(uriString).inputStream()
            }

            inputStream?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream) ?: return null
                // Resize if too large to keep HTML/PDF fast and small
                val scaledBitmap = if (bitmap.width > 600 || bitmap.height > 600) {
                    val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
                    val newWidth = if (ratio > 1) 600 else (600 * ratio).toInt()
                    val newHeight = if (ratio > 1) (600 / ratio).toInt() else 600
                    Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
                } else {
                    bitmap
                }

                val outputStream = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
                val bytes = outputStream.toByteArray()
                "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
            }
        } catch (_: Exception) {
            null
        }
    }
}
