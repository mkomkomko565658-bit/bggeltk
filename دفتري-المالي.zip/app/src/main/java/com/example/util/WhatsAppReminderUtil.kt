package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri

object WhatsAppReminderUtil {

    /**
     * Formats a polite, professional Arabic WhatsApp reminder for outstanding debts.
     */
    fun buildReminderMessage(
        businessName: String,
        customerName: String,
        debtAmount: Double,
        currency: String,
        lastTransactionDate: String,
        dueDate: String = ""
    ): String {
        val amountStr = if (debtAmount % 1.0 == 0.0) debtAmount.toLong().toString() else "%.2f".format(debtAmount)
        val dateInfo = if (lastTransactionDate.isNotBlank()) "📅 تاريخ آخر حركة: $lastTransactionDate\n" else ""
        val dueInfo = if (dueDate.isNotBlank()) "⏰ موعد السداد المتفق عليه: $dueDate\n" else ""

        return """
السلام عليكم ورحمة الله وبركاته أخي $customerName 🌹
نود تذكيركم بمتبقي الحساب المستحق لديكم لدى "$businessName":
💰 المبلغ المتبقي: $amountStr $currency
$dateInfo$dueInfo
شاكرين ومقدرين حسن تعاملكم الطيب معنا دائماً.
        """.trimIndent()
    }

    fun buildReminderMessage(
        businessName: String,
        customerName: String,
        netBalance: Double,
        currency: String,
        dueDate: String = ""
    ): String {
        val debtAmount = if (netBalance < 0) -netBalance else netBalance
        return buildReminderMessage(businessName, customerName, debtAmount, currency, "", dueDate)
    }

    /**
     * Normalizes a phone number to standard international format.
     */
    fun cleanPhoneNumber(rawPhone: String): String {
        var digits = rawPhone.replace(Regex("[^0-9]"), "")
        if (digits.startsWith("00")) {
            digits = digits.substring(2)
        }
        if (digits.startsWith("0") && digits.length >= 10) {
            digits = digits.substring(1)
        }
        // Auto prefix Yemen or Saudi if missing country code
        if (digits.length == 9 && (digits.startsWith("7") || digits.startsWith("1"))) {
            digits = "967$digits"
        } else if (digits.length == 9 && digits.startsWith("5")) {
            digits = "966$digits"
        }
        return digits
    }

    /**
     * Sends the debt reminder directly via WhatsApp or falls back to system share.
     */
    fun sendReminder(context: Context, rawPhone: String, message: String) {
        val cleanPhone = cleanPhoneNumber(rawPhone)
        if (cleanPhone.isNotBlank()) {
            try {
                val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {}
        }

        // Fallback: general share intent
        try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, message)
                type = "text/plain"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(sendIntent, "إرسال التذكير عبر").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) {}
    }

    fun shareToWhatsApp(context: Context, message: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                setPackage("com.whatsapp")
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            sendReminder(context, "", message)
        }
    }
}
